<?php 
defined('_JEXEC') or die("Access Deny");

echo JText::_('COM_WELCOME_MESSAGE');



 ?>