<?php 

defined('_JEXEC')or die("restricted");

echo  Jtext::_('COM_WELCOME_MESSAGE');



?>